package utill;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.mycompany.modelo.Vehiculo;
import com.mycompany.modelo.Usuario;

public class DatosSistema {

    private static final ObservableList<Vehiculo> listaVehiculos = FXCollections.observableArrayList();
    private static final ObservableList<Usuario> listaUsuarios = FXCollections.observableArrayList();

    static {
        listaVehiculos.add(new Vehiculo("Kawasaki H2", "Motocicleta", 35000.0, "/imagenes/H.jpg"));
        listaVehiculos.add(new Vehiculo("Nissan GT-R", "Automóvil", 115000.0, "/imagenes/Gtr.jpg"));
        listaVehiculos.add(new Vehiculo("BMW S1000RR", "Motocicleta", 20000.0, "/imagenes/Bmw.jpg"));
        listaVehiculos.add(new Vehiculo("Chevrolet Camaro", "Automóvil", 45000.0, "/imagenes/Camaro.jpg"));

        listaUsuarios.add(new Usuario("admin", "1234", "admin"));
        listaUsuarios.add(new Usuario("cliente@pw.com", "1234", "cliente"));
    }

    public static ObservableList<Vehiculo> getListaVehiculos() {
        return listaVehiculos;
    }

    public static void agregarVehiculo(Vehiculo vehiculo) {
        listaVehiculos.add(vehiculo);
    }

    // ¡Este era el método que faltaba para los usuarios!
    public static ObservableList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }
}