package com.mycompany.modelo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // Carga el archivo login.fxml desde la carpeta resources
        Parent root = FXMLLoader.load(getClass().getResource("/login.fxml"));
        
        primaryStage.setTitle("pwConcessionaire - Inicio de Sesión");
        primaryStage.setScene(new Scene(root, 400, 300));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}