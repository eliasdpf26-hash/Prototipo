package controlador;

import com.mycompany.modelo.Vehiculo;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;
import utill.DatosSistema;

import java.net.URL;
import java.util.ResourceBundle;

public class CatalogoController implements Initializable {

    @FXML
    private TilePane tilePaneVehiculos;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Recorremos la lista de vehículos precargados en DatosSistema
        for (Vehiculo v : DatosSistema.getListaVehiculos()) {
            VBox tarjeta = crearTarjetaVehiculo(v);
            tilePaneVehiculos.getChildren().add(tarjeta);
        }
    }

    private VBox crearTarjetaVehiculo(Vehiculo v) {
        VBox card = new VBox(10);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: white; -fx-border-color: #d3d3d3; -fx-border-radius: 5; -fx-background-radius: 5;");
        card.setPrefWidth(210);

        // Imagen del vehículo
        ImageView imageView = new ImageView();
        try {
            Image img = new Image(getClass().getResourceAsStream("/" + v.getRutaImagen()));
            imageView.setImage(img);
        } catch (Exception e) {
            // Si la imagen no existe aún, continúa sin error
        }
        imageView.setFitWidth(150);
        imageView.setFitHeight(100);
        imageView.setPreserveRatio(true);

        Label lblNombre = new Label(v.getNombre());
        lblNombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

        Label lblCategoria = new Label("Categoría: " + v.getCategoria());
        Label lblPrecio = new Label("Precio: $" + v.getPrecio());

        // Botón verde para carrito
        Button btnComprar = new Button("Agregar al carrito");
        btnComprar.setStyle("-fx-background-color: #28a745; -fx-text-fill: white;");
        btnComprar.setOnAction(e -> {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
            alert.setTitle("Carrito");
            alert.setHeaderText(null);
            alert.setContentText("¡Agregado al carrito: " + v.getNombre() + "!");
            alert.showAndWait();
        });

        // Botón rojo para deseos
        Button btnDeseos = new Button("Añadir a deseos");
        btnDeseos.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white;");
        btnDeseos.setOnAction(e -> {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
            alert.setTitle("Lista de Deseos");
            alert.setHeaderText(null);
            alert.setContentText("¡Añadido a deseos: " + v.getNombre() + "!");
            alert.showAndWait();
        });

        card.getChildren().addAll(imageView, lblNombre, lblCategoria, lblPrecio, btnComprar, btnDeseos);
        return card;
    }
}