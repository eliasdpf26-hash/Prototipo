package controlador;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import utill.DatosSistema;
import com.mycompany.modelo.Usuario;

public class LoginController {

    @FXML
    private TextField txtUsuario;

    @FXML
    private PasswordField txtPassword;

    @FXML
    private void iniciarSesion() {
        String user = txtUsuario.getText();
        String pass = txtPassword.getText();

        boolean encontrado = false;
        String rol = "";

        // Recorremos la lista de usuarios precargados en DatosSistema
        for (Usuario u : DatosSistema.getListaUsuarios()) {
            if (u.getCorreo().equals(user) && u.getPassword().equals(pass)) {
                encontrado = true;
                rol = u.getRol();
                break;
            }
        }

        if (encontrado) {
            try {
                // Cambiamos la escena actual para cargar el catálogo
                javafx.stage.Stage stage = (javafx.stage.Stage) txtUsuario.getScene().getWindow();
                javafx.scene.Parent root = javafx.fxml.FXMLLoader.load(getClass().getResource("/catalogo.fxml"));
                stage.setScene(new javafx.scene.Scene(root));
                stage.setTitle("pwConcessionaire - Catálogo de Vehículos");
                stage.centerOnScreen();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error de Acceso");
            alert.setHeaderText(null);
            alert.setContentText("Usuario o contraseña incorrectos.");
            alert.showAndWait();
        }
    }
}